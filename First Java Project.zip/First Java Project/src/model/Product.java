package model;

public class Product {
	
	String productId;
	String productName;
	String productDesc;
	String price;
	String stock;
	String category;
	String supplier;
	String userName;
	String Passwd1;
	
	public Product() {}
	
	public Product(String productId, String productName, String productDesc, String price, String stock, String category,
			String supplier, String userName, String passwd) {
		//super();
		this.productId = productId;
		this.productName = productName;
		this.productDesc = productDesc;
		this.price = price;
		this.stock = stock;
		this.category = category;
		this.supplier = supplier;
		this.userName = userName;
		Passwd1 = passwd;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPasswd() {
		return Passwd1;
	}

	public void setPasswd(String passwd) {
		Passwd1 = passwd;
	}

	String Passwd;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getPrice() {
		return price;
	}

	public void setPrice(String price) {
		this.price = price;
	}

	public String getStock() {
		return stock;
	}

	public void setStock(String stock) {
		this.stock = stock;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getSupplier() {
		return supplier;
	}

	public void setSupplier(String supplier) {
		this.supplier = supplier;
	}

}
