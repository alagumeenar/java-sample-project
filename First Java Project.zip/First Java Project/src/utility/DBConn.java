package utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConn 
{
	static Connection conn;
	public static Connection getMySQLConnection()throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		//final String url = "jdbc:mysql://practice";
		//final String user = "root";
		//final String password = "ScottUser@01";
		
		//conn= DriverManager.getConnection(url, user, password) ;
		
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/practice","root","ScottUser@01");
		return conn;
		
	     
	}
	
}
