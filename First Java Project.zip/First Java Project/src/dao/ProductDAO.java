package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//import controller.ProductController;
import model.Product;
import utility.DBConn;

public class ProductDAO 
{
	Connection conn;
	public ProductDAO()throws Exception
	{
		conn = DBConn.getMySQLConnection();
	}
	
	public boolean productDetails(Product product)throws SQLException
	{
		PreparedStatement psmt=conn.prepareStatement("insert into products values(?,?,?,?,?,?,?,?,?)");
		
		psmt.setString(1, product.getProductId());
		psmt.setString(2, product.getProductName());
		psmt.setString(3, product.getProductDesc());
		psmt.setString(4, product.getPrice());
		psmt.setString(5, product.getStock());
		psmt.setString(6,product.getCategory());
		psmt.setString(7, product.getSupplier());
		psmt.setString(8,product.getUserName());
		psmt.setString(9,product.getPasswd());
	
		int row_eff=psmt.executeUpdate();
		
		if(row_eff>0)
			return true;
		else
			return false;
	}
	
	public Product checkCredential(Product product)throws SQLException
	{
		PreparedStatement psmt=conn.prepareStatement("select * from products where username=? and password1=?");
		
		psmt.setString(1, product.getUserName());
		psmt.setString(2, product.getPasswd());
		
		ResultSet rs=psmt.executeQuery();
		
		if(rs.next())
		{
			product.setUserName(rs.getString(8));
		}
		else
		{
			product=null;
		}
		
		return product;
	}
}

