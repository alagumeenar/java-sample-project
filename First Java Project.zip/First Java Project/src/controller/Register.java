package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ProductDAO;
import model.Product;

@WebServlet("/Register")
public class Register extends HttpServlet 
{
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
	
		try
		{
			String productId=request.getParameter("productId");
			String productName=request.getParameter("productName");
			String productDesc=request.getParameter("productDesc");
			String price=request.getParameter("price");
			String stock=request.getParameter("stock");
			String category=request.getParameter("category");
			String supplier=request.getParameter("supplier");
			String userName=request.getParameter("userName");
			String Passwd1=request.getParameter("Passwd1");
			
		
		Product product=new Product(productId,productName,productDesc,price,stock,category,supplier,userName, Passwd1 );
		
		ProductDAO productDAO=new ProductDAO();
		
			if(productDAO.productDetails(product))
			{
				request.setAttribute("username", product.getUserName());
				request.setAttribute("productName", product.getProductName());
				RequestDispatcher dispatch=request.getRequestDispatcher("UserHome.jsp");
				dispatch.forward(request, response);
			}
			else
			{
				request.setAttribute("errorInfo","Error Occured During Registering");
				RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
				dispatch.forward(request, response);
			}
		
		}
		catch(Exception e)
		{
			request.setAttribute("errorInfo","Error Occured During Registering::::"+e.getMessage());
			RequestDispatcher dispatch=request.getRequestDispatcher("ErrorPage.jsp");
			dispatch.forward(request, response);
		}
		
	}

}
